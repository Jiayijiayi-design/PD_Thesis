import torch
from torch.autograd import Variable
from torch.nn.parameter import Parameter
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torch.nn.init as init
from torch.nn import Linear, Conv2d, BatchNorm2d, MaxPool2d, Dropout
from torch.nn.functional import relu, elu, relu6, sigmoid, tanh, softmax
import torch.optim as optim
import glob
from torch.utils.data import Dataset, DataLoader
import math
import pandas as pd
import os
from os import listdir
from os.path import join, isfile
import numpy as np
from torch.utils.data.sampler import SubsetRandomSampler
from datetime import date, datetime
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score
##------------##------------##------------##------------##------------##------------##------------##------------

class ParkinsonsDataset(Dataset):
    def __init__(self):

        pathLabels = '/work3/s164229/bagData/Labels_all.csv'

        self.pathFiles = '/work3/s164229/bagData'

        self.y = pd.read_csv(pathLabels)

        self.label = self.y['filenames']

    def __len__(self):
        return len(self.label)

    def __getitem__(self, index):

        tempath = self.y.iloc[index]['filenames']

        signalpath = os.path.join(self.pathFiles,tempath)

        self.x = torch.from_numpy(np.load(signalpath).astype(np.double))
       # self.x =  self.x[:,:,[0,1,2]] # select only 3 dimension, 3D-acc on Left side [0,1,2]

        return self.x, self.y.iloc[index]['binary']

# Define model
class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()

        self.L = 16
        self.K = 1
        self.M = 64
        ## feature extraction
        self.featureExtract = nn.Sequential(nn.Conv1d(in_channels =12 , out_channels = 32, kernel_size=8, padding =1,stride = 1),
                                            nn.LeakyReLU(negative_slope=0.2),
                                            nn.MaxPool1d(2),
                                            nn.Conv1d(in_channels = 32,out_channels = 32, kernel_size=8,padding =1, stride = 1),
                                            nn.LeakyReLU(negative_slope=0.2),
                                            nn.MaxPool1d(2),
                                            nn.Conv1d(in_channels = 32, out_channels = 16, kernel_size=16, padding =1, stride = 1),
                                            nn.LeakyReLU(negative_slope=0.2),
                                            nn.MaxPool1d(2),
                                            nn.Conv1d(in_channels = 16, out_channels = 16, kernel_size=16, padding =1, stride = 1),
                                            nn.LeakyReLU(negative_slope=0.2),
                                            nn.MaxPool1d(2),
                                            nn.Flatten(),
                                            nn.Linear(320, self.M))

        self.attention = nn.Sequential(nn.Linear(self.M, self.L),
                                       nn.Tanh(),
                                       nn.Linear(self.L, self.K))

        self.classify = nn.Sequential(nn.Linear(self.M,32),
                                      nn.LeakyReLU(negative_slope=0.2),
                                      Dropout(p = 0.2, inplace = False),
                                      nn.Linear(32,16),
                                      nn.LeakyReLU(negative_slope=0.2),
                                      Dropout(p = 0.2, inplace = False),
                                      nn.Linear(16,2),
                                      nn.Softmax(dim = 1))

    def forward(self, x):
        ## feature extraction

        H = self.featureExtract(x)

        A = self.attention(H)
        A = torch.transpose(A,1,0)
        s = nn.Softmax(dim=1)
        A = s(A)

        z = torch.mm(A,H) # summing the product of attention and features

        #Y_prob = self.classify(z)
        #Y_hat = torch.ge(Y_prob,0.5).float()

        output = self.classify(z)
        Y_prob , Y_hat = torch.max(output,dim=1)

        return Y_prob, Y_hat, A


    def calculate_classification_error(self, X, Y):
        Y = Y.float()
        _, Y_hat, _ = self.forward(X)
        error = 1. - Y_hat.eq(Y).cpu().float().mean().item()
        return error, Y_hat

    def calculate_objective(self, X, Y):
        Y = Y.float()
        Y_prob, _, A = self.forward(X)
        Y_prob = torch.clamp(Y_prob, min=1e-5, max=1. - 1e-5)
        neg_log_likelihood = -1. * (Y * torch.log(Y_prob) + (1. - Y) * torch.log(1. - Y_prob))  # negative log bernoulli
        return neg_log_likelihood, A

##------------##------------##------------##------------##------------##------------##------------##------------

# CUDA for PyTorch
use_cuda = torch.cuda.is_available()
device = torch.device("cuda:0" if use_cuda else "cpu")
torch.backends.cudnn.benchmark = True

print('The device for this training is:',device)

model = Net().to(device)

##------------##------------##------------##------------##------------##------------##------------##------------
print('--------------------------------------------------------------------------------------')
print('Defined model contains following layers:')
print('--------------------------------------------------------------------------------------')
print(model)
print('--------------------------------------------------------------------------------------')
##------------##------------##------------##------------##------------##------------##------------##------------
pd_data = ParkinsonsDataset()

batch_size = 1
validation_split = .2
shuffle_dataset = True
random_seed= 42

# Creating data indices for training and validation splits:
dataset_size = len(pd_data)
indices = list(range(dataset_size))
split = int(np.floor(validation_split * dataset_size))
if shuffle_dataset :
    np.random.seed(random_seed)
    np.random.shuffle(indices)
train_indices, val_indices = indices[split:], indices[:split]

# Creating PT data samplers and loaders:
train_sampler = SubsetRandomSampler(train_indices)
valid_sampler = SubsetRandomSampler(val_indices)


train_loader = DataLoader(dataset = pd_data,  batch_size = batch_size, sampler = train_sampler)

test_loader = DataLoader(dataset = pd_data,  batch_size = batch_size, sampler = valid_sampler)

print('Data Loading is succesfull')



print('Data Loading is succesfull')

total_samples = len(train_loader)

n_iterations = math.ceil(total_samples/batch_size)

print('Selected batch size:', batch_size)
print('Number of iterations:',n_iterations)
print('Number of samples:',total_samples)


# define optimization criteria

lr = 0.001

#criterion = nn.CrossEntropyLoss()
#criterion = nn.NLLLoss()

#optimizer = optim.Adam(model.parameters(), lr=lr, betas=(0.9, 0.999), weight_decay=0.9)
#optimizer = optim.Adam(model.parameters(), lr=lr)
optimizer = optim.SGD(model.parameters(), lr=lr, momentum=0.9)

error_criterion = nn.CrossEntropyLoss()
loss_criterion = nn.NLLLoss()

num_epoch = 200

m = nn.LogSoftmax(dim=1)

num_samples_train = len(train_loader)

num_batches_train = num_samples_train // batch_size

mSigmoid = nn.Sigmoid()

criterion = nn.BCELoss()

def train():

    print('Current model parameters')
    print('Batch size', batch_size)
    print('Epoch size',num_epoch )
    print('Number of iterations for training in total',n_iterations*batch_size)
    print('Learning rate', lr)
    print('optimizer', optimizer)
    if batch_size > 1:
        losses, accuracy = train_batch_epoch()
    else:
        losses, accuracy = train_epoch()

    print(losses)
    print(accuracy)

    ## change back to cpu for plotting
    cpu_device = torch.device("cpu")

    print('Training sucessfull')
    print('Generating figure')
    ## Generate figure
    epoch = np.arange(num_epoch)

    fig=plt.figure(figsize=(15,10))
    plt.plot(epoch,losses.to(cpu_device).detach().numpy())
    plt.plot(epoch,accuracy.to(cpu_device).detach().numpy())
    plt.legend(['training loss','accuracy'])
    plt.xlabel('Epoch')
    plt.show()

    now = datetime.now()
    dt_string = now.strftime("%d-%m-%Y-%H-%M")

    fig.savefig('/zhome/37/8/118154/Documents/figures/'+str(dt_string)+'-test.png') ## save figure

    return losses, accuracy

def train_epoch():
    model.train()
    print('Training started')
    losses = torch.empty((num_epoch))
    accuracy = torch.empty((num_epoch))
    for epoch in range(num_epoch):
        # initialize
        train_loss = 0.
        train_acc = 0.
        if (epoch+1)% 20 == 0: # print out every 5th iteration
            print(f'step {epoch+1}/{num_epoch}')


        for i, (data, bag_label) in enumerate(train_loader):

            if use_cuda:
                data, bag_label = data.to(device, dtype=torch.float), bag_label.to(device, dtype=torch.float)
            else:
                data, bag_label = data.type(torch.float), bag_label.type(torch.float)

            # wrap them in Variable
            data, bag_label = Variable(data), Variable(bag_label)

            data=torch.swapaxes(data,3,2)

            data = torch.squeeze(data)

            Y_prob, Y_hat, A = model(data)

            acc = accuracy_score(bag_label.cpu(), Y_hat.cpu())
            train_acc += acc

            loss = criterion(mSigmoid(torch.unsqueeze(Y_prob,0)), torch.unsqueeze(bag_label,0))
            train_loss += loss.item()

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        losses[epoch] = train_loss/len(train_loader)
        accuracy[epoch] = train_acc/len(train_loader)

    now = datetime.now()
    dt_string = now.strftime("%d-%m-%Y-%H-%M")
    PATH = '/zhome/37/8/118154/Documents/Model/'+str(dt_string)+'trainModel.pth'
    torch.save(model.state_dict(), PATH)
    print(losses)
    print(accuracy)
    return losses, accuracy

def train_batch_epoch():
    model.train()
    losses = torch.empty((num_epoch))
    errors = torch.empty((num_epoch))

    for epoch in range(num_epoch):

        # initialize
        train_loss = 0.
        train_error = 0.
        if (epoch+1)% 5 == 0: # print out every 5th iteration
            print(f'step {epoch+1}/{num_epoch}')

        for i, (data, bag_label) in enumerate(train_loader):

            if use_cuda:
                data, bag_label = data.to(device, dtype=torch.float), bag_label.to(device, dtype=torch.float)
            else:
                data, bag_label = data.type(torch.float), bag_label.type(torch.float)

            # wrap them in Variable
            data, bag_label = Variable(data), Variable(bag_label)

            print('Current batch size', batch_size)

            batch_Y_prob = torch.empty((batch_size), dtype=torch.float, device = device)
            batch_Y_hat = torch.empty((batch_size), dtype=torch.float, device = device)
            batch_loss = 0.
            batch_error = 0.

            data=torch.swapaxes(data,3,2)

            for i in range(batch_size):
                print('Batch',i+1)
                data_i = data[i,:,:,:]

                loss, _ = model.calculate_objective(data_i, bag_label[i])
                batch_loss += loss.data[0]
                error, _ = model.calculate_classification_error(data_i, bag_label[i])
                batch_error += error

            batch_error /= (batch_size)
            batch_loss /= (batch_size)


            batch_loss = Variable(batch_loss, requires_grad=True)
            batch_loss.backward()

            optimizer.step()

        losses[epoch] = batch_loss/len(train_loader)
        errors[epoch] = batch_error/len(train_loader)

    now = datetime.now()
    dt_string = now.strftime("%d-%m-%Y-%H-%M")
    PATH = '/zhome/37/8/118154/Documents/Model/'+str(dt_string)+'trainModel.pth'
    torch.save(model.state_dict(), PATH)

    return losses, errors, batch_loss, batch_error


losses, accuracy = train()
# testing loop
def test():
    model.eval()
    test_loss = 0.
    test_acc = 0.

    print('Testing started')

    for i, (data, bag_label) in enumerate(test_loader):
        if (i+1)% 10 == 0: # print out every 5th iteration
            print(f'step {i+1}/{len(test_loader)}')

        if use_cuda:
            data, bag_label = data.to(device, dtype=torch.float), bag_label.to(device, dtype=torch.float)
        else:
            data, bag_label = data.type(torch.float), bag_label.type(torch.float)

        # wrap them in Variable
        data, bag_label = Variable(data), Variable(bag_label)
        data=torch.swapaxes(data,3,2)
        data = torch.squeeze(data)
        data = data.float()

        Y_prob, Y_hat, A = model(data)


        acc = accuracy_score(bag_label.cpu(), Y_hat.cpu())
        test_acc += acc

        loss = criterion(mSigmoid(torch.unsqueeze(Y_prob,0)), torch.unsqueeze(bag_label,0))
        test_loss += loss.item()

    test_acc /= len(test_loader)
    test_loss /= len(test_loader)

    print(f'test accuracy {test_acc} and test loss {test_loss}')

test()
